# modelling/modelling.py
from model.randomforest import RandomForest
import numpy as np

def model_predict(data, df, name):
    # Check if training data exists
    if data.X_train is None:
        print(f"Skipping group {name} due to insufficient data")
        return

    # Instantiate the RandomForest model
    model = RandomForest()

    # Train the model using embeddings (X_train) and target (y_train)
    model.train(data.X_train, data.y_train)

    # Predict on test data
    predictions = model.predict(data.X_test)

    # Calculate accuracy (assuming a simple accuracy metric for now)
    accuracy = np.mean(predictions == data.y_test)
    print(f"Group {name} - Accuracy: {accuracy:.2f}")


def model_evaluate(model, data):
    model.print_results(data)

import numpy as np
import pandas as pd
from model.randomforest import RandomForest
from model.chained_classifier import ChainedClassifier

def chained_accuracy(y_true: pd.DataFrame, y_pred: list[np.ndarray]) -> float:
    """
    Compute chained accuracy: fraction of consecutive correct predictions per instance.
    :param y_true: DataFrame with true labels ['y2', 'y3', 'y4'].
    :param y_pred: List of predicted labels [y2_pred, y3_pred, y4_pred].
    :return: Average chained accuracy across instances.
    """
    n_instances = len(y_true)
    total_score = 0
    for i in range(n_instances):
        score = 0
        for j, col in enumerate(y_true.columns):
            if y_pred[j][i] == y_true.iloc[i][col]:
                score += 1
            else:
                break
        total_score += score / len(y_true.columns)
    return total_score / n_instances

def perform_modelling(data, df, name):
    if data.X_train is None:
        print(f"Skipping group {name} due to insufficient data")
        return

    models = [RandomForest() for _ in range(3)]
    chained_clf = ChainedClassifier(models)
    chained_clf.train(data.X_train, data.y_train)
    predictions = chained_clf.predict(data.X_test)
    accuracy = chained_accuracy(data.y_test, predictions)
    print(f"Group {name} - Chained Accuracy: {accuracy:.2f}")