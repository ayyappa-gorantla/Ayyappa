import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from Config import Config
import random

seed = 0
random.seed(seed)
np.random.seed(seed)

class Data:
    def __init__(self, X: np.ndarray, df: pd.DataFrame) -> None:
        y = df[Config.TYPE_COLS]  # DataFrame with 'y2', 'y3', 'y4'

        # Filter classes with at least 5 instances for each label
        good_y2 = y['y2'].value_counts()[y['y2'].value_counts() >= 5].index
        good_y3 = y['y3'].value_counts()[y['y3'].value_counts() >= 5].index
        good_y4 = y['y4'].value_counts()[y['y4'].value_counts() >= 5].index

        # Keep instances where all labels have sufficient instances
        mask = (y['y2'].isin(good_y2)) & (y['y3'].isin(good_y3)) & (y['y4'].isin(good_y4))
        if mask.sum() < 5:
            print("Too few instances after filtering: Skipping ...")
            self.X_train = None
            return

        X_good = X[mask]
        y_good = y[mask]

        # Adjust test size to approximate 20% of original data
        new_test_size = min(0.2 * X.shape[0] / X_good.shape[0], 0.5)

        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X_good, y_good, test_size=new_test_size, random_state=0, stratify=y_good['y2']
        )
        self.classes_y2 = good_y2
        self.classes_y3 = good_y3
        self.classes_y4 = good_y4
        self.embeddings = X_good