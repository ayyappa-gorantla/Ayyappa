import numpy as np
from model.base import BaseModel
from sklearn.ensemble import RandomForestClassifier
import random

seed = 0
random.seed(seed)
np.random.seed(seed)

class RandomForest(BaseModel):
    def __init__(self):
        self.mdl = RandomForestClassifier(
            n_estimators=1000,
            random_state=seed,
            class_weight='balanced_subsample'
        )

    def train(self, X: np.ndarray, y: np.ndarray) -> None:
        self.mdl.fit(X, y)

    def predict(self, X: np.ndarray) -> np.ndarray:
        return self.mdl.predict(X)