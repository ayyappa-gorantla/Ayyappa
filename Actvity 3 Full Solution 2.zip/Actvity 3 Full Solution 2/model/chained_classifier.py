import numpy as np
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from model.base import BaseModel

class ChainedClassifier:
    def __init__(self, models: list[BaseModel], label_cols: list[str] = ['y2', 'y3', 'y4']):
        """
        Initialize the chained classifier with a list of models and label columns.
        :param models: List of BaseModel instances for each label.
        :param label_cols: List of label column names (default: ['y2', 'y3', 'y4']).
        """
        self.models = models
        self.label_cols = label_cols
        self.encoders = [OneHotEncoder(handle_unknown='ignore', sparse_output=False) for _ in range(len(label_cols))]

    def train(self, X_train: np.ndarray, y_train: pd.DataFrame) -> None:
        """
        Train the models sequentially, using previous true labels as features.
        :param X_train: Training feature matrix (numpy array).
        :param y_train: Training labels (DataFrame with 'y2', 'y3', 'y4').
        """
        for i, col in enumerate(self.label_cols):
            if i == 0:
                X_train_current = X_train
            else:
                prev_labels = y_train[self.label_cols[:i]].values
                encoded = np.hstack([
                    self.encoders[j].fit_transform(prev_labels[:, j].reshape(-1, 1))
                    for j in range(i)
                ])
                X_train_current = np.hstack([X_train, encoded])
            self.models[i].train(X_train_current, y_train[col])

    def predict(self, X_test: np.ndarray) -> list[np.ndarray]:
        """
        Predict labels sequentially, using previous predictions as features.
        :param X_test: Test feature matrix (numpy array).
        :return: List of predictions [y2_pred, y3_pred, y4_pred].
        """
        predictions = []
        current_X = X_test.copy()
        prev_preds = []
        for i, model in enumerate(self.models):
            pred = model.predict(current_X)
            predictions.append(pred)
            if i < len(self.models) - 1:
                prev_preds.append(pred)
                encoded = np.hstack([
                    self.encoders[j].transform(prev_preds[j].reshape(-1, 1))
                    for j in range(i + 1)
                ])
                current_X = np.hstack([X_test, encoded])
        return predictions